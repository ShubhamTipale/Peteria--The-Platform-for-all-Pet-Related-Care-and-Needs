package com.app.service;

import java.util.List;


import com.app.entities.Hostel;
;

public interface IHostelService {


    List<Hostel> fetchAllHostels();
	
    //add a method to delete Hostel details
	String deleteHostelDetails(int HostelId);
	//add method to fetch Hostel details
	Hostel getHostelDetails(int HostelId);
	//update Hostel
	Hostel updateHostelDetails(Hostel detachedHostel);

	Hostel saveHostelDetails(Hostel transientHostel);
}
