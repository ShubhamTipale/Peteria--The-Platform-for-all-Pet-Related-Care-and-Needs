package com.app.service;

import java.util.List;

import com.app.entities.Vet;

public interface IVetService {

    List<Vet> fetchAllVets();
	
    //add a method to delete Vet details
	String deleteVetDetails(int VetId);
	//add method to fetch Vet details
	Vet getVetDetails(int VetId);
	//update Vet
	Vet updateVetDetails(Vet detachedVet);

	Vet saveVetDetails(Vet transientVet);
	
}
