package com.app.entities;

public enum Status {
	PENDING,  IN_DELIVERY , COMPLETE , PLACED; 
}	
